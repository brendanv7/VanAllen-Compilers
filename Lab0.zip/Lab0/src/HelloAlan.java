/**
 * This class serves as a test to ensure you can properly
 * run my projects.
 */
public class HelloAlan {
    public static void main(String args[]) {
        System.out.println("Hello Alan!");
    }
}
